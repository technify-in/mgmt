-- phpMyAdmin SQL Dump
-- version 3.3.7
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 19, 2015 at 07:07 PM
-- Server version: 5.5.41
-- PHP Version: 5.5.9-1ubuntu4.7

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `bankim`
--

-- --------------------------------------------------------

--
-- Table structure for table `actionlog`
--

CREATE TABLE IF NOT EXISTS `actionlog` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(11) NOT NULL,
  `datetime` datetime NOT NULL,
  `comment` varchar(255) NOT NULL,
  `table` varchar(64) NOT NULL,
  `fieldid` int(11) NOT NULL DEFAULT '0',
  `type` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=123 ;

--
-- Dumping data for table `actionlog`
--

INSERT INTO `actionlog` (`id`, `userid`, `datetime`, `comment`, `table`, `fieldid`, `type`) VALUES
(1, 1, '2014-01-13 21:35:44', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(2, 1, '2014-01-13 22:10:20', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(3, 1, '2014-01-13 22:10:26', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(4, 1, '2014-01-13 22:16:30', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(5, 1, '2014-01-13 22:17:29', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(6, 1, '2014-01-13 22:18:03', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(7, 1, '2014-01-13 22:19:48', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(8, 1, '2014-01-13 22:20:51', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(9, 1, '2014-01-13 22:20:58', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(10, 1, '2014-01-13 22:21:00', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(11, 1, '2014-01-13 22:21:04', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(12, 1, '2014-01-13 22:34:07', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(13, 1, '2014-01-13 22:34:12', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(14, 1, '2014-01-13 23:03:01', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(15, 1, '2014-01-13 23:03:05', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(16, 1, '2014-01-13 23:24:45', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(17, 1, '2014-01-13 23:24:54', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(18, 1, '2014-01-13 23:26:17', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(19, 1, '2014-01-13 23:27:41', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(20, 1, '2014-01-13 23:28:09', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(21, 1, '2014-01-13 23:28:43', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(22, 1, '2014-01-13 23:30:27', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(23, 1, '2014-01-13 23:30:39', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(24, 1, '2014-01-13 23:30:41', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(25, 1, '2014-01-13 23:30:48', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(26, 1, '2014-01-13 23:32:51', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(27, 1, '2014-01-13 23:32:56', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(28, 1, '2014-01-13 23:33:06', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(29, 1, '2014-01-13 23:34:37', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(30, 1, '2014-01-13 23:34:51', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(31, 1, '2014-01-13 23:39:27', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(32, 1, '2014-01-13 23:40:37', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(33, 1, '2014-01-13 23:40:40', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(34, 1, '2014-01-13 23:42:15', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(35, 1, '2014-01-13 23:42:19', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(36, 1, '2014-01-13 23:43:43', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(37, 1, '2014-01-13 23:43:47', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(38, 1, '2014-01-13 23:44:49', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(39, 1, '2014-01-13 23:44:53', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(40, 1, '2014-01-13 23:45:14', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(41, 1, '2014-01-13 23:46:21', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(42, 1, '2014-01-13 23:50:36', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(43, 1, '2014-01-13 23:50:54', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(44, 1, '2014-01-13 23:52:09', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(45, 1, '2014-01-13 23:52:41', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(46, 1, '2014-01-13 23:53:07', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(47, 1, '2014-01-13 23:53:13', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(48, 1, '2014-01-13 23:53:19', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(49, 1, '2014-01-13 23:53:45', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(50, 1, '2014-01-13 23:54:32', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(51, 1, '2014-01-13 23:54:58', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(52, 1, '2014-01-13 23:56:22', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(53, 1, '2014-01-13 23:56:26', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(54, 1, '2014-01-13 23:56:33', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(55, 1, '2014-01-13 23:56:37', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(56, 1, '2014-01-14 00:04:25', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(57, 1, '2014-01-14 00:04:37', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(58, 1, '2014-01-14 00:04:44', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(59, 1, '2014-01-14 00:14:37', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64; rv:26.0) Gecko/20100101 Firefox/26.0)', 'users', 1, 0),
(60, 1, '2014-01-14 00:14:49', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64; rv:26.0) Gecko/20100101 Firefox/26.0)', 'users', 1, 0),
(61, 1, '2014-01-14 00:23:35', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(62, 1, '2014-01-14 00:23:55', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(63, 1, '2014-01-14 00:24:05', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(64, 1, '2014-01-14 00:24:12', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(65, 1, '2014-01-14 00:24:14', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(66, 1, '2014-01-14 01:41:48', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(67, 1, '2014-01-14 01:41:59', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(68, 1, '2014-01-14 19:58:17', 'Login: (IP: 192.168.1.2, User Agent: Mozilla/5.0 (iPhone; CPU iPhone OS 6_1_2 like Mac OS X) AppleWebKit/536.26 (KHTML, like Gecko) Version/6.0 Mobile/10B146 Safari/8536.25)', 'users', 1, 0),
(69, 1, '2014-01-14 19:58:44', 'Logout: (IP: 192.168.1.2, User Agent: Mozilla/5.0 (iPhone; CPU iPhone OS 6_1_2 like Mac OS X) AppleWebKit/536.26 (KHTML, like Gecko) Version/6.0 Mobile/10B146 Safari/8536.25)', 'users', 1, 0),
(70, 1, '2014-01-15 16:50:39', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(71, 1, '2014-01-15 16:52:08', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(72, 1, '2014-01-15 16:52:12', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(73, 1, '2014-01-15 16:53:15', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(74, 1, '2014-01-15 16:53:21', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(75, 1, '2014-01-15 16:53:31', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(76, 1, '2014-01-15 16:54:39', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(77, 1, '2014-01-15 18:42:23', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.29 Safari/537.36)', 'users', 1, 0),
(78, 1, '2014-01-15 18:43:20', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.29 Safari/537.36)', 'users', 1, 0),
(79, 1, '2014-01-15 18:56:46', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.29 Safari/537.36)', 'users', 1, 0),
(80, 1, '2014-01-15 18:57:18', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.29 Safari/537.36)', 'users', 1, 0),
(81, 1, '2014-01-17 10:44:54', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.29 Safari/537.36)', 'users', 1, 0),
(82, 1, '2014-01-17 10:45:13', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.29 Safari/537.36)', 'users', 1, 0),
(83, 1, '2014-01-17 10:45:19', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.29 Safari/537.36)', 'users', 1, 0),
(84, 1, '2014-01-22 16:37:14', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.29 Safari/537.36)', 'users', 1, 0),
(85, 1, '2014-01-22 16:38:14', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.29 Safari/537.36)', 'users', 1, 0),
(86, 1, '2014-01-23 20:05:39', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64; rv:26.0) Gecko/20100101 Firefox/26.0)', 'users', 1, 0),
(87, 1, '2014-02-02 17:37:38', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64; rv:26.0) Gecko/20100101 Firefox/26.0)', 'users', 1, 0),
(88, 1, '2014-02-02 17:37:44', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64; rv:26.0) Gecko/20100101 Firefox/26.0)', 'users', 1, 0),
(89, 1, '2014-02-02 23:34:56', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64; rv:26.0) Gecko/20100101 Firefox/26.0)', 'users', 1, 0),
(90, 1, '2014-02-02 23:35:07', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64; rv:26.0) Gecko/20100101 Firefox/26.0)', 'users', 1, 0),
(91, 1, '2014-02-02 23:42:59', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/34.0.1809.0 Safari/537.36)', 'users', 1, 0),
(92, 1, '2014-02-02 23:58:20', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/34.0.1809.0 Safari/537.36)', 'users', 1, 0),
(93, 1, '2014-02-03 00:08:17', 'Added feeder details for ', 'Villages', 1, 1),
(94, 1, '2014-02-03 01:28:51', 'Added new invoice ', 'Invoice', 1, 1),
(95, 1, '2014-02-04 21:46:08', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64; rv:26.0) Gecko/20100101 Firefox/26.0)', 'users', 1, 0),
(96, 1, '2014-02-04 21:54:21', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64; rv:26.0) Gecko/20100101 Firefox/26.0)', 'users', 1, 0),
(97, 1, '2014-02-04 22:03:46', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64; rv:26.0) Gecko/20100101 Firefox/26.0)', 'users', 1, 0),
(98, 1, '2014-02-04 23:04:44', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64; rv:26.0) Gecko/20100101 Firefox/26.0)', 'users', 1, 0),
(99, 1, '2014-02-04 23:05:03', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64; rv:26.0) Gecko/20100101 Firefox/26.0)', 'users', 1, 0),
(100, 1, '2014-02-04 23:23:01', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64; rv:26.0) Gecko/20100101 Firefox/26.0)', 'users', 1, 0),
(101, 1, '2014-02-04 23:23:07', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64; rv:26.0) Gecko/20100101 Firefox/26.0)', 'users', 1, 0),
(102, 1, '2014-02-04 23:33:58', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64; rv:26.0) Gecko/20100101 Firefox/26.0)', 'users', 1, 0),
(103, 1, '2014-02-04 23:36:59', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64; rv:26.0) Gecko/20100101 Firefox/26.0)', 'users', 1, 0),
(104, 1, '2014-02-04 23:40:24', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64; rv:26.0) Gecko/20100101 Firefox/26.0)', 'users', 1, 0),
(105, 1, '2014-02-04 23:40:35', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64; rv:26.0) Gecko/20100101 Firefox/26.0)', 'users', 1, 0),
(106, 1, '2014-02-04 23:43:48', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64; rv:26.0) Gecko/20100101 Firefox/26.0)', 'users', 1, 0),
(107, 1, '2014-02-04 23:43:53', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64; rv:26.0) Gecko/20100101 Firefox/26.0)', 'users', 1, 0),
(108, 1, '2014-02-04 23:45:07', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64; rv:26.0) Gecko/20100101 Firefox/26.0)', 'users', 1, 0),
(109, 1, '2014-02-04 23:45:11', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64; rv:26.0) Gecko/20100101 Firefox/26.0)', 'users', 1, 0),
(110, 1, '2014-02-05 01:09:19', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64; rv:26.0) Gecko/20100101 Firefox/26.0)', 'users', 1, 0),
(111, 1, '2014-02-05 01:09:25', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64; rv:26.0) Gecko/20100101 Firefox/26.0)', 'users', 1, 0),
(112, 1, '2014-02-05 01:17:58', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64; rv:26.0) Gecko/20100101 Firefox/26.0)', 'users', 1, 0),
(113, 1, '2014-02-05 01:18:02', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64; rv:26.0) Gecko/20100101 Firefox/26.0)', 'users', 1, 0),
(114, 1, '2014-02-05 01:49:33', 'Added new invoice 100', 'Invoice', 1, 2),
(115, 1, '2014-02-05 01:50:23', 'Added new invoice 101', 'Invoice', 1, 3),
(116, 1, '2014-02-05 02:32:04', 'Added new invoice itemHTC One X', 'Stock Items', 1, 2),
(117, 1, '2014-02-05 02:33:51', 'Added new invoice itemiPhone 5S', 'Stock Items', 1, 3),
(118, 1, '2015-04-19 18:05:30', 'Login: (IP: 127.0.0.1, User Agent: Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:37.0) Gecko/20100101 Firefox/37.0)', 'users', 1, 0),
(119, 1, '2015-04-19 18:17:32', 'Login: (IP: 192.168.1.2, User Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_5) AppleWebKit/600.3.18 (KHTML, like Gecko) Version/7.1.3 Safari/537.85.12)', 'users', 1, 0),
(120, 1, '2015-04-19 18:20:37', 'Added new invoice itemiPhone 5S 16GB Gold', 'Stock Items', 1, 4),
(121, 1, '2015-04-19 18:33:13', 'Added new invoice V68', 'Invoice', 1, 4),
(122, 1, '2015-04-19 18:41:22', 'Login: (IP: 127.0.0.1, User Agent: Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:37.0) Gecko/20100101 Firefox/37.0)', 'users', 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `distributorinvoices`
--

CREATE TABLE IF NOT EXISTS `distributorinvoices` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `distributorid` int(10) unsigned NOT NULL,
  `invoicenumber` varchar(20) NOT NULL,
  `invoicedate` date NOT NULL,
  `description` text NOT NULL,
  `noofitems` int(10) unsigned NOT NULL,
  `amount` decimal(12,2) NOT NULL,
  `modified` datetime NOT NULL,
  `modifiedby` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `distributorid` (`distributorid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `distributorinvoices`
--

INSERT INTO `distributorinvoices` (`id`, `distributorid`, `invoicenumber`, `invoicedate`, `description`, `noofitems`, `amount`, `modified`, `modifiedby`) VALUES
(1, 1, '99', '2014-02-03', 'Some description of items in invoice', 2, 100000.00, '2014-02-03 01:28:50', 0),
(2, 1, '100', '2014-02-05', '', 2, 100000.00, '2014-02-05 01:49:33', 0),
(3, 1, '101', '2014-02-05', '', 2, 100000.00, '2014-02-05 01:50:22', 0),
(4, 1, 'V68', '2015-04-08', '1x 4s\r\n2x355', 5, 14445.00, '2015-04-19 18:33:13', 0);

-- --------------------------------------------------------

--
-- Table structure for table `distributors`
--

CREATE TABLE IF NOT EXISTS `distributors` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  `contactperson` varchar(64) NOT NULL,
  `address` text NOT NULL,
  `mobile` varchar(12) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `email` varchar(64) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `distributors`
--

INSERT INTO `distributors` (`id`, `name`, `contactperson`, `address`, `mobile`, `phone`, `email`) VALUES
(1, 'Appli Fruit Co', 'Sabji Wala', 'Some Fruit Mandi', '12345676', '1234', 'apple@fruit.co');

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE IF NOT EXISTS `roles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role` varchar(255) NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `admin` tinyint(1) NOT NULL DEFAULT '0',
  `viewallactionlog` tinyint(1) NOT NULL DEFAULT '0',
  `createusers` tinyint(1) NOT NULL DEFAULT '0',
  `changeownpassword` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `role` (`role`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `role`, `enabled`, `admin`, `viewallactionlog`, `createusers`, `changeownpassword`) VALUES
(1, 'Administrator', 1, 1, 1, 1, 1),
(2, 'View Reports', 1, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `salesinvoice`
--

CREATE TABLE IF NOT EXISTS `salesinvoice` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `invoicedate` date NOT NULL,
  `customername` varchar(64) NOT NULL,
  `customermobile` varchar(12) NOT NULL,
  `address` text NOT NULL,
  `email` varchar(64) NOT NULL,
  `comment` text NOT NULL,
  `modfied` datetime NOT NULL,
  `modifiedby` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `modifiedby` (`modifiedby`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `salesinvoice`
--


-- --------------------------------------------------------

--
-- Table structure for table `salesinvoiceitems`
--

CREATE TABLE IF NOT EXISTS `salesinvoiceitems` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `salesinvoiceid` int(10) unsigned NOT NULL,
  `stockitemid` int(10) unsigned NOT NULL,
  `discount` decimal(12,2) NOT NULL,
  `rp` decimal(12,2) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `salesinvoiceid` (`salesinvoiceid`,`stockitemid`),
  KEY `stockitemid` (`stockitemid`),
  KEY `salesinvoiceid_2` (`salesinvoiceid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `salesinvoiceitems`
--


-- --------------------------------------------------------

--
-- Table structure for table `stockitems`
--

CREATE TABLE IF NOT EXISTS `stockitems` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `stockitemtypeid` int(10) unsigned NOT NULL,
  `distributorinvoiceid` int(10) unsigned NOT NULL,
  `sku` varchar(64) NOT NULL,
  `barcode` varchar(256) NOT NULL,
  `itemname` varchar(64) NOT NULL,
  `bp` decimal(12,2) NOT NULL COMMENT 'Base price without tax',
  `taxrateid` int(3) unsigned NOT NULL,
  `description` text NOT NULL,
  `mrp` decimal(12,2) NOT NULL,
  `quantity` int(11) NOT NULL DEFAULT '1' COMMENT 'Quantity of Similar Items in Stock',
  `salesinvoiceid` int(10) unsigned NOT NULL,
  `modified` datetime NOT NULL,
  `modifiedby` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `stockitemtypeid` (`stockitemtypeid`),
  KEY `distributorinvoiceid` (`distributorinvoiceid`),
  KEY `salesinvoiceid` (`salesinvoiceid`),
  KEY `modifiedby` (`modifiedby`),
  KEY `barcode` (`barcode`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `stockitems`
--

INSERT INTO `stockitems` (`id`, `stockitemtypeid`, `distributorinvoiceid`, `sku`, `barcode`, `itemname`, `bp`, `taxrateid`, `description`, `mrp`, `quantity`, `salesinvoiceid`, `modified`, `modifiedby`) VALUES
(2, 3, 2, '112333444', '112112334', 'HTC One X', 10000.00, 1, '', 20000.00, 10, 0, '2014-02-05 02:32:04', 0),
(3, 2, 2, '3222344', '112112334111', 'iPhone 5S', 30000.00, 1, '', 60000.00, 5, 0, '2014-02-05 02:33:51', 0),
(4, 2, 2, 'MG782HN/A', 'thisisthat', 'iPhone 5S 16GB Gold', 47500.00, 1, '', 53500.00, 1, 0, '2015-04-19 18:20:37', 0);

-- --------------------------------------------------------

--
-- Table structure for table `stockitemtypes`
--

CREATE TABLE IF NOT EXISTS `stockitemtypes` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `parentcategoryid` int(11) unsigned NOT NULL,
  `type` varchar(32) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `type` (`type`),
  KEY `parentcategoryid` (`parentcategoryid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=18 ;

--
-- Dumping data for table `stockitemtypes`
--

INSERT INTO `stockitemtypes` (`id`, `parentcategoryid`, `type`) VALUES
(1, 0, 'Mobile Phone'),
(2, 1, 'iPhone'),
(3, 1, 'Android'),
(4, 1, 'Windows Phone'),
(5, 1, 'Blackberry'),
(6, 1, 'Other Mobile'),
(7, 0, 'Tab'),
(8, 7, 'iPad'),
(9, 7, 'Android Tab'),
(10, 7, 'Other Tab'),
(11, 0, 'Accessory'),
(12, 11, 'Case/ Cover'),
(13, 11, 'Charger'),
(14, 11, 'Other Accesory'),
(15, 0, 'Computer/ Laptop'),
(16, 15, 'Mac/ Macbook'),
(17, 15, 'PC/ Laptop');

-- --------------------------------------------------------

--
-- Table structure for table `taxrates`
--

CREATE TABLE IF NOT EXISTS `taxrates` (
  `id` int(3) unsigned NOT NULL AUTO_INCREMENT,
  `description` varchar(64) NOT NULL,
  `taxrate` decimal(4,2) NOT NULL,
  `validfrom` date NOT NULL COMMENT 'Date rate applicable',
  `validto` date NOT NULL COMMENT 'Date rate applicable upto',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COMMENT='Tax rates applicable' AUTO_INCREMENT=4 ;

--
-- Dumping data for table `taxrates`
--

INSERT INTO `taxrates` (`id`, `description`, `taxrate`, `validfrom`, `validto`) VALUES
(1, '13% - Accessory and iPod', 14.30, '2013-04-01', '2016-03-31'),
(2, '8.5% - Phones', 9.35, '2013-04-01', '2016-03-31'),
(3, '5.5% - IT Products', 6.05, '2015-04-01', '2016-03-31');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `lastlogin` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `local` varchar(10) NOT NULL DEFAULT 'en',
  `role` tinyint(1) NOT NULL DEFAULT '0',
  `mod_datetime` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `lastlogin`, `enabled`, `local`, `role`, `mod_datetime`) VALUES
(1, 'admin', '21232f297a57a5a743894a0e4a801fc3', '2015-04-19 18:41:22', 1, 'en', 1, '2009-04-20 14:08:40');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `distributorinvoices`
--
ALTER TABLE `distributorinvoices`
  ADD CONSTRAINT `distributorinvoices_ibfk_1` FOREIGN KEY (`distributorid`) REFERENCES `distributors` (`id`);

--
-- Constraints for table `salesinvoiceitems`
--
ALTER TABLE `salesinvoiceitems`
  ADD CONSTRAINT `salesinvoiceitems_ibfk_1` FOREIGN KEY (`salesinvoiceid`) REFERENCES `salesinvoice` (`id`),
  ADD CONSTRAINT `salesinvoiceitems_ibfk_2` FOREIGN KEY (`stockitemid`) REFERENCES `stockitems` (`id`);

--
-- Constraints for table `stockitems`
--
ALTER TABLE `stockitems`
  ADD CONSTRAINT `stockitems_ibfk_1` FOREIGN KEY (`stockitemtypeid`) REFERENCES `stockitemtypes` (`id`),
  ADD CONSTRAINT `stockitems_ibfk_2` FOREIGN KEY (`distributorinvoiceid`) REFERENCES `distributorinvoices` (`id`);
