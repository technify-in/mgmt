-- phpMyAdmin SQL Dump
-- version 4.0.10deb1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: May 08, 2015 at 02:18 AM
-- Server version: 5.6.22-1+deb.sury.org~trusty+1
-- PHP Version: 5.5.9-1ubuntu4.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `mgmt`
--

-- --------------------------------------------------------

--
-- Table structure for table `actionlog`
--

CREATE TABLE IF NOT EXISTS `actionlog` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(11) NOT NULL,
  `datetime` datetime NOT NULL,
  `comment` varchar(255) NOT NULL,
  `table` varchar(64) NOT NULL,
  `fieldid` int(11) NOT NULL DEFAULT '0',
  `type` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=154 ;

--
-- Dumping data for table `actionlog`
--

INSERT INTO `actionlog` (`id`, `userid`, `datetime`, `comment`, `table`, `fieldid`, `type`) VALUES
(1, 1, '2014-01-13 21:35:44', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(2, 1, '2014-01-13 22:10:20', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(3, 1, '2014-01-13 22:10:26', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(4, 1, '2014-01-13 22:16:30', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(5, 1, '2014-01-13 22:17:29', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(6, 1, '2014-01-13 22:18:03', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(7, 1, '2014-01-13 22:19:48', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(8, 1, '2014-01-13 22:20:51', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(9, 1, '2014-01-13 22:20:58', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(10, 1, '2014-01-13 22:21:00', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(11, 1, '2014-01-13 22:21:04', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(12, 1, '2014-01-13 22:34:07', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(13, 1, '2014-01-13 22:34:12', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(14, 1, '2014-01-13 23:03:01', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(15, 1, '2014-01-13 23:03:05', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(16, 1, '2014-01-13 23:24:45', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(17, 1, '2014-01-13 23:24:54', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(18, 1, '2014-01-13 23:26:17', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(19, 1, '2014-01-13 23:27:41', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(20, 1, '2014-01-13 23:28:09', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(21, 1, '2014-01-13 23:28:43', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(22, 1, '2014-01-13 23:30:27', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(23, 1, '2014-01-13 23:30:39', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(24, 1, '2014-01-13 23:30:41', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(25, 1, '2014-01-13 23:30:48', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(26, 1, '2014-01-13 23:32:51', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(27, 1, '2014-01-13 23:32:56', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(28, 1, '2014-01-13 23:33:06', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(29, 1, '2014-01-13 23:34:37', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(30, 1, '2014-01-13 23:34:51', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(31, 1, '2014-01-13 23:39:27', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(32, 1, '2014-01-13 23:40:37', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(33, 1, '2014-01-13 23:40:40', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(34, 1, '2014-01-13 23:42:15', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(35, 1, '2014-01-13 23:42:19', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(36, 1, '2014-01-13 23:43:43', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(37, 1, '2014-01-13 23:43:47', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(38, 1, '2014-01-13 23:44:49', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(39, 1, '2014-01-13 23:44:53', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(40, 1, '2014-01-13 23:45:14', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(41, 1, '2014-01-13 23:46:21', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(42, 1, '2014-01-13 23:50:36', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(43, 1, '2014-01-13 23:50:54', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(44, 1, '2014-01-13 23:52:09', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(45, 1, '2014-01-13 23:52:41', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(46, 1, '2014-01-13 23:53:07', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(47, 1, '2014-01-13 23:53:13', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(48, 1, '2014-01-13 23:53:19', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(49, 1, '2014-01-13 23:53:45', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(50, 1, '2014-01-13 23:54:32', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(51, 1, '2014-01-13 23:54:58', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(52, 1, '2014-01-13 23:56:22', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(53, 1, '2014-01-13 23:56:26', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(54, 1, '2014-01-13 23:56:33', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(55, 1, '2014-01-13 23:56:37', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(56, 1, '2014-01-14 00:04:25', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(57, 1, '2014-01-14 00:04:37', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(58, 1, '2014-01-14 00:04:44', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(59, 1, '2014-01-14 00:14:37', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64; rv:26.0) Gecko/20100101 Firefox/26.0)', 'users', 1, 0),
(60, 1, '2014-01-14 00:14:49', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64; rv:26.0) Gecko/20100101 Firefox/26.0)', 'users', 1, 0),
(61, 1, '2014-01-14 00:23:35', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(62, 1, '2014-01-14 00:23:55', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(63, 1, '2014-01-14 00:24:05', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(64, 1, '2014-01-14 00:24:12', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(65, 1, '2014-01-14 00:24:14', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(66, 1, '2014-01-14 01:41:48', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(67, 1, '2014-01-14 01:41:59', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(68, 1, '2014-01-14 19:58:17', 'Login: (IP: 192.168.1.2, User Agent: Mozilla/5.0 (iPhone; CPU iPhone OS 6_1_2 like Mac OS X) AppleWebKit/536.26 (KHTML, like Gecko) Version/6.0 Mobile/10B146 Safari/8536.25)', 'users', 1, 0),
(69, 1, '2014-01-14 19:58:44', 'Logout: (IP: 192.168.1.2, User Agent: Mozilla/5.0 (iPhone; CPU iPhone OS 6_1_2 like Mac OS X) AppleWebKit/536.26 (KHTML, like Gecko) Version/6.0 Mobile/10B146 Safari/8536.25)', 'users', 1, 0),
(70, 1, '2014-01-15 16:50:39', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(71, 1, '2014-01-15 16:52:08', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(72, 1, '2014-01-15 16:52:12', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(73, 1, '2014-01-15 16:53:15', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(74, 1, '2014-01-15 16:53:21', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(75, 1, '2014-01-15 16:53:31', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(76, 1, '2014-01-15 16:54:39', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.5 Safari/537.36)', 'users', 1, 0),
(77, 1, '2014-01-15 18:42:23', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.29 Safari/537.36)', 'users', 1, 0),
(78, 1, '2014-01-15 18:43:20', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.29 Safari/537.36)', 'users', 1, 0),
(79, 1, '2014-01-15 18:56:46', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.29 Safari/537.36)', 'users', 1, 0),
(80, 1, '2014-01-15 18:57:18', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.29 Safari/537.36)', 'users', 1, 0),
(81, 1, '2014-01-17 10:44:54', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.29 Safari/537.36)', 'users', 1, 0),
(82, 1, '2014-01-17 10:45:13', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.29 Safari/537.36)', 'users', 1, 0),
(83, 1, '2014-01-17 10:45:19', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.29 Safari/537.36)', 'users', 1, 0),
(84, 1, '2014-01-22 16:37:14', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.29 Safari/537.36)', 'users', 1, 0),
(85, 1, '2014-01-22 16:38:14', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.29 Safari/537.36)', 'users', 1, 0),
(86, 1, '2014-01-23 20:05:39', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64; rv:26.0) Gecko/20100101 Firefox/26.0)', 'users', 1, 0),
(87, 1, '2014-02-02 17:37:38', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64; rv:26.0) Gecko/20100101 Firefox/26.0)', 'users', 1, 0),
(88, 1, '2014-02-02 17:37:44', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64; rv:26.0) Gecko/20100101 Firefox/26.0)', 'users', 1, 0),
(89, 1, '2014-02-02 23:34:56', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64; rv:26.0) Gecko/20100101 Firefox/26.0)', 'users', 1, 0),
(90, 1, '2014-02-02 23:35:07', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64; rv:26.0) Gecko/20100101 Firefox/26.0)', 'users', 1, 0),
(91, 1, '2014-02-02 23:42:59', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/34.0.1809.0 Safari/537.36)', 'users', 1, 0),
(92, 1, '2014-02-02 23:58:20', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/34.0.1809.0 Safari/537.36)', 'users', 1, 0),
(93, 1, '2014-02-03 00:08:17', 'Added feeder details for ', 'Villages', 1, 1),
(94, 1, '2014-02-03 01:28:51', 'Added new invoice ', 'Invoice', 1, 1),
(95, 1, '2014-02-04 21:46:08', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64; rv:26.0) Gecko/20100101 Firefox/26.0)', 'users', 1, 0),
(96, 1, '2014-02-04 21:54:21', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64; rv:26.0) Gecko/20100101 Firefox/26.0)', 'users', 1, 0),
(97, 1, '2014-02-04 22:03:46', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64; rv:26.0) Gecko/20100101 Firefox/26.0)', 'users', 1, 0),
(98, 1, '2014-02-04 23:04:44', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64; rv:26.0) Gecko/20100101 Firefox/26.0)', 'users', 1, 0),
(99, 1, '2014-02-04 23:05:03', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64; rv:26.0) Gecko/20100101 Firefox/26.0)', 'users', 1, 0),
(100, 1, '2014-02-04 23:23:01', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64; rv:26.0) Gecko/20100101 Firefox/26.0)', 'users', 1, 0),
(101, 1, '2014-02-04 23:23:07', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64; rv:26.0) Gecko/20100101 Firefox/26.0)', 'users', 1, 0),
(102, 1, '2014-02-04 23:33:58', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64; rv:26.0) Gecko/20100101 Firefox/26.0)', 'users', 1, 0),
(103, 1, '2014-02-04 23:36:59', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64; rv:26.0) Gecko/20100101 Firefox/26.0)', 'users', 1, 0),
(104, 1, '2014-02-04 23:40:24', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64; rv:26.0) Gecko/20100101 Firefox/26.0)', 'users', 1, 0),
(105, 1, '2014-02-04 23:40:35', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64; rv:26.0) Gecko/20100101 Firefox/26.0)', 'users', 1, 0),
(106, 1, '2014-02-04 23:43:48', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64; rv:26.0) Gecko/20100101 Firefox/26.0)', 'users', 1, 0),
(107, 1, '2014-02-04 23:43:53', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64; rv:26.0) Gecko/20100101 Firefox/26.0)', 'users', 1, 0),
(108, 1, '2014-02-04 23:45:07', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64; rv:26.0) Gecko/20100101 Firefox/26.0)', 'users', 1, 0),
(109, 1, '2014-02-04 23:45:11', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64; rv:26.0) Gecko/20100101 Firefox/26.0)', 'users', 1, 0),
(110, 1, '2014-02-05 01:09:19', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64; rv:26.0) Gecko/20100101 Firefox/26.0)', 'users', 1, 0),
(111, 1, '2014-02-05 01:09:25', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64; rv:26.0) Gecko/20100101 Firefox/26.0)', 'users', 1, 0),
(112, 1, '2014-02-05 01:17:58', 'Logout: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64; rv:26.0) Gecko/20100101 Firefox/26.0)', 'users', 1, 0),
(113, 1, '2014-02-05 01:18:02', 'Login: (IP: ::1, User Agent: Mozilla/5.0 (X11; Linux x86_64; rv:26.0) Gecko/20100101 Firefox/26.0)', 'users', 1, 0),
(114, 1, '2014-02-05 01:49:33', 'Added new invoice 100', 'Invoice', 1, 2),
(115, 1, '2014-02-05 01:50:23', 'Added new invoice 101', 'Invoice', 1, 3),
(116, 1, '2014-02-05 02:32:04', 'Added new invoice itemHTC One X', 'Stock Items', 1, 2),
(117, 1, '2014-02-05 02:33:51', 'Added new invoice itemiPhone 5S', 'Stock Items', 1, 3),
(118, 1, '2015-04-19 18:05:30', 'Login: (IP: 127.0.0.1, User Agent: Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:37.0) Gecko/20100101 Firefox/37.0)', 'users', 1, 0),
(119, 1, '2015-04-19 18:17:32', 'Login: (IP: 192.168.1.2, User Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_5) AppleWebKit/600.3.18 (KHTML, like Gecko) Version/7.1.3 Safari/537.85.12)', 'users', 1, 0),
(120, 1, '2015-04-19 18:20:37', 'Added new invoice itemiPhone 5S 16GB Gold', 'Stock Items', 1, 4),
(121, 1, '2015-04-19 18:33:13', 'Added new invoice V68', 'Invoice', 1, 4),
(122, 1, '2015-04-19 18:41:22', 'Login: (IP: 127.0.0.1, User Agent: Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:37.0) Gecko/20100101 Firefox/37.0)', 'users', 1, 0),
(123, 1, '2015-04-23 01:56:24', 'Login: (IP: 124.253.133.49, User Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_5) AppleWebKit/600.3.18 (KHTML, like Gecko) Version/7.1.3 Safari/537.85.12)', 'users', 1, 0),
(124, 1, '2015-04-23 03:13:54', 'Login: (IP: 124.253.133.49, User Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_5) AppleWebKit/600.3.18 (KHTML, like Gecko) Version/7.1.3 Safari/537.85.12)', 'users', 1, 0),
(125, 1, '2015-04-23 03:52:00', 'Login: (IP: 124.253.133.49, User Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_5) AppleWebKit/600.3.18 (KHTML, like Gecko) Version/7.1.3 Safari/537.85.12)', 'users', 1, 0),
(126, 1, '2015-04-23 14:49:50', 'Login: (IP: 203.134.194.91, User Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_5) AppleWebKit/600.3.18 (KHTML, like Gecko) Version/7.1.3 Safari/537.85.12)', 'users', 1, 0),
(127, 1, '2015-04-23 21:26:24', 'Login: (IP: 203.134.194.91, User Agent: Mozilla/5.0 (iPhone; CPU iPhone OS 8_3 like Mac OS X) AppleWebKit/600.1.4 (KHTML, like Gecko) Version/8.0 Mobile/12F70 Safari/600.1.4)', 'users', 1, 0),
(128, 1, '2015-04-25 03:57:32', 'Login: (IP: 124.253.183.98, User Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_5) AppleWebKit/600.3.18 (KHTML, like Gecko) Version/7.1.3 Safari/537.85.12)', 'users', 1, 0),
(129, 1, '2015-04-25 04:13:33', 'Logout: (IP: 124.253.183.98, User Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_5) AppleWebKit/600.3.18 (KHTML, like Gecko) Version/7.1.3 Safari/537.85.12)', 'users', 1, 0),
(130, 1, '2015-04-25 04:13:38', 'Login: (IP: 124.253.183.98, User Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_5) AppleWebKit/600.3.18 (KHTML, like Gecko) Version/7.1.3 Safari/537.85.12)', 'users', 1, 0),
(131, 1, '2015-04-25 14:16:11', 'Login: (IP: 203.134.194.91, User Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_5) AppleWebKit/600.3.18 (KHTML, like Gecko) Version/7.1.3 Safari/537.85.12)', 'users', 1, 0),
(132, 1, '2015-04-27 04:52:41', 'Login: (IP: 124.253.58.105, User Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_5) AppleWebKit/600.3.18 (KHTML, like Gecko) Version/7.1.3 Safari/537.85.12)', 'users', 1, 0),
(133, 1, '2015-05-02 01:14:01', 'Login: (IP: 124.253.86.108, User Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/42.0.2311.135 Safari/537.36)', 'users', 1, 0),
(134, 1, '2015-05-02 01:16:07', 'Added new Distributor BAMA Infotech', 'Distributors', 1, 2),
(135, 1, '2015-05-02 01:43:00', 'Login: (IP: 117.205.51.125, User Agent: Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:37.0) Gecko/20100101 Firefox/37.0)', 'users', 1, 0),
(136, 1, '2015-05-02 01:56:31', 'Added new Distributor Dummy Distributor', 'Distributors', 1, 3),
(137, 1, '2015-05-02 02:09:15', 'Logout: (IP: 124.253.86.108, User Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/42.0.2311.135 Safari/537.36)', 'users', 1, 0),
(138, 1, '2015-05-02 02:09:22', 'Login: (IP: 124.253.86.108, User Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/42.0.2311.135 Safari/537.36)', 'users', 1, 0),
(139, 1, '2015-05-02 02:10:14', 'Added new invoice V101', 'Invoice', 1, 5),
(140, 1, '2015-05-02 02:17:59', 'Added new invoice itemiPhone 5S 16GB Gold', 'Stock Items', 1, 5),
(141, 1, '2015-05-02 02:29:52', 'Added new invoice itemiPhone 4S 8GB White', 'Stock Items', 1, 6),
(142, 1, '2015-05-02 11:52:17', 'Login: (IP: 203.134.194.91, User Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_5) AppleWebKit/600.5.17 (KHTML, like Gecko) Version/7.1.5 Safari/537.85.14)', 'users', 1, 0),
(143, 1, '2015-05-02 23:58:31', 'Login: (IP: 124.253.139.247, User Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_5) AppleWebKit/600.3.18 (KHTML, like Gecko) Version/7.1.3 Safari/537.85.12)', 'users', 1, 0),
(144, 1, '2015-05-03 02:29:02', 'Login: (IP: 124.253.139.247, User Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_5) AppleWebKit/600.3.18 (KHTML, like Gecko) Version/7.1.3 Safari/537.85.12)', 'users', 1, 0),
(145, 1, '2015-05-03 16:34:34', 'Login: (IP: 117.205.63.162, User Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_5) AppleWebKit/600.3.18 (KHTML, like Gecko) Version/7.1.3 Safari/537.85.12)', 'users', 1, 0),
(146, 1, '2015-05-03 17:55:05', 'Login: (IP: 203.134.194.91, User Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_5) AppleWebKit/600.3.18 (KHTML, like Gecko) Version/7.1.3 Safari/537.85.12)', 'users', 1, 0),
(147, 1, '2015-05-04 17:14:30', 'Login: (IP: 203.134.194.91, User Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_5) AppleWebKit/600.5.17 (KHTML, like Gecko) Version/7.1.5 Safari/537.85.14)', 'users', 1, 0),
(148, 1, '2015-05-06 02:06:44', 'Login: (IP: 124.253.137.38, User Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_5) AppleWebKit/600.3.18 (KHTML, like Gecko) Version/7.1.3 Safari/537.85.12)', 'users', 1, 0),
(149, 1, '2015-05-07 00:31:30', 'Login: (IP: 124.253.174.85, User Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_5) AppleWebKit/600.3.18 (KHTML, like Gecko) Version/7.1.3 Safari/537.85.12)', 'users', 1, 0),
(150, 1, '2015-05-07 23:59:40', 'Login: (IP: 124.253.213.169, User Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_5) AppleWebKit/600.3.18 (KHTML, like Gecko) Version/7.1.3 Safari/537.85.12)', 'users', 1, 0),
(151, 1, '2015-05-08 00:02:50', 'Login: (IP: 124.253.213.169, User Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/42.0.2311.135 Safari/537.36)', 'users', 1, 0),
(152, 1, '2015-05-08 01:10:56', 'Login: (IP: 124.253.213.169, User Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_5) AppleWebKit/600.3.18 (KHTML, like Gecko) Version/7.1.3 Safari/537.85.12)', 'users', 1, 0),
(153, 1, '2015-05-08 02:07:20', 'Logout: (IP: 124.253.213.169, User Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_5) AppleWebKit/600.3.18 (KHTML, like Gecko) Version/7.1.3 Safari/537.85.12)', 'users', 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE IF NOT EXISTS `customers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  `address` text NOT NULL,
  `mobile` varchar(12) NOT NULL,
  `email` varchar(64) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `distributorinvoices`
--

CREATE TABLE IF NOT EXISTS `distributorinvoices` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `distributorid` int(10) unsigned NOT NULL,
  `invoicenumber` varchar(20) NOT NULL,
  `invoicedate` date NOT NULL,
  `description` text NOT NULL,
  `noofitems` int(10) unsigned NOT NULL,
  `amount` decimal(12,2) NOT NULL,
  `modified` datetime NOT NULL,
  `modifiedby` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `distributorid` (`distributorid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=121 ;

--
-- Dumping data for table `distributorinvoices`
--

INSERT INTO `distributorinvoices` (`id`, `distributorid`, `invoicenumber`, `invoicedate`, `description`, `noofitems`, `amount`, `modified`, `modifiedby`) VALUES
(1, 1, 'V0001', '2014-04-02', '1 x iPod Shuffle', 1, 3426.00, '2014-02-03 01:28:50', 0),
(2, 1, 'V0011', '2014-04-02', '2 x 5S 16GB Gold\r\n2 x 5S 16GB Space Gray', 4, 205768.00, '2014-02-05 01:49:33', 0),
(3, 1, 'V0008', '2014-04-02', '1 x iPad Mini WiFi + Cell 16GB White', 1, 29712.00, '2014-02-05 01:50:22', 0),
(4, 1, 'V0069', '2014-04-19', '2 x 4S White', 2, 60576.00, '2015-04-19 18:33:13', 0),
(5, 1, 'V0101', '2014-05-01', '1 x iPhone 5S', 1, 51442.00, '2015-05-02 02:10:14', 0),
(6, 1, '80', '2013-05-17', '2 x iPhone 4 8GB White\r2 x iPhone 4 8GB Black', 4, 101924.00, '0000-00-00 00:00:00', 0),
(7, 1, '123', '2013-05-30', '1 x iPhone 5 16GB Black\r\n1 x iPhone 5 16GB Silver', 2, 87500.00, '0000-00-00 00:00:00', 0),
(8, 1, '124', '2013-05-30', '1 x iPad Retina Wifi + Cell 16GB Black\r\n1 x iPad Retina Wifi + Cell 16GB Silver', 2, 66609.00, '0000-00-00 00:00:00', 0),
(9, 1, '125', '2013-05-30', '5 x EarPods', 5, 9164.98, '0000-00-00 00:00:00', 0),
(10, 1, '131', '2013-06-01', '1 x iPhone 5 16GB White\r2 x iPhone 4 8GB Black', 3, 94712.00, '0000-00-00 00:00:00', 0),
(11, 1, '135', '2013-06-05', '2 x iPhone 4 8GB White\r1 x iPhone 5 16GB Silver', 3, 94712.00, '0000-00-00 00:00:00', 0),
(30, 1, '152', '2013-06-11', '2 x iPhone 4 8GB White', 2, 50962.00, '0000-00-00 00:00:00', 0),
(31, 1, '158', '2013-06-13', '1 x iPhone 4 8GB Black\n1 x iPhone 4 8GB White', 2, 50962.00, '0000-00-00 00:00:00', 0),
(32, 1, '170', '2013-06-17', '2 x iPhone 5 16GB White', 2, 87500.00, '0000-00-00 00:00:00', 0),
(33, 1, '175', '2013-06-18', '2 x iPhone 5 16GB White', 2, 87500.00, '0000-00-00 00:00:00', 0),
(34, 1, '191', '2013-06-21', '1 x iPhone 5 16GB Black', 1, 43750.00, '0000-00-00 00:00:00', 0),
(35, 1, '199', '2013-06-24', '2 x iPhone 5 16GB White', 2, 87500.00, '0000-00-00 00:00:00', 0),
(36, 1, '230', '2013-07-03', '1 x iPhone 4 8GB White', 1, 25481.00, '0000-00-00 00:00:00', 0),
(37, 1, '241', '2013-07-06', '2 x iPhone 4 8GB White', 2, 50962.00, '0000-00-00 00:00:00', 0),
(38, 1, '242', '2013-07-06', '1 x iPad Mini 16GB WiFi White', 1, 21024.00, '0000-00-00 00:00:00', 0),
(39, 1, '243', '2013-07-06', '2 x EarPods', 2, 3666.00, '0000-00-00 00:00:00', 0),
(40, 1, '245', '2013-07-06', '1 x iPhone 5 16GB Black', 1, 43750.00, '0000-00-00 00:00:00', 0),
(41, 1, '252', '2013-07-09', '3 x iPhone 4 8GB Black\n4 x iPhone 4 8GB White', 7, 178367.00, '0000-00-00 00:00:00', 0),
(42, 1, '271', '2013-07-09', '2 x iPhone 4 16GB White', 2, 61154.00, '0000-00-00 00:00:00', 0),
(43, 1, '273', '2013-07-09', '2 x iPhone 4 8GB White', 2, 50962.00, '0000-00-00 00:00:00', 0),
(44, 1, '312', '2013-07-09', '1 x iPhone 4 8GB White', 1, 25481.00, '0000-00-00 00:00:00', 0),
(45, 1, '315', '2013-07-09', '1 x iPad Mini 16GB WiFi Black', 1, 21024.00, '0000-00-00 00:00:00', 0),
(46, 1, '316', '2013-07-09', 'iPad 4 16GB WiFi Black Demo', 1, 24244.00, '0000-00-00 00:00:00', 0),
(47, 1, '322', '2013-07-25', '1 x iPhone 5 16GB Black', 1, 43750.00, '0000-00-00 00:00:00', 0),
(48, 1, '332', '2013-07-27', 'iPad 4 16GB WiFi White', 1, 30305.00, '0000-00-00 00:00:00', 0),
(49, 1, '343', '2013-07-31', '1 x iPhone 5 16GB Black\n1 x iPhone 5 16GB White', 2, 87500.00, '0000-00-00 00:00:00', 0),
(50, 1, '344', '2013-07-31', '1 x iPhone 4 16GB Black', 1, 30577.00, '0000-00-00 00:00:00', 0),
(51, 1, '351', '2013-08-02', '6 x Apple TV', 6, 38170.00, '0000-00-00 00:00:00', 0),
(52, 1, '371', '2013-08-05', '2 x iPhone 4 8GB White', 2, 50962.00, '0000-00-00 00:00:00', 0),
(53, 1, '400', '2013-08-09', '2 x iPhone 5 16GB White\n1 x iPhone 4 8GB Black', 3, 112981.00, '0000-00-00 00:00:00', 0),
(54, 1, '408', '2013-08-10', '1 x iPhone 4 16GB White', 1, 61154.00, '0000-00-00 00:00:00', 0),
(55, 1, '429', '2013-08-14', '1 x iPhone 4 8GB White', 1, 25481.00, '0000-00-00 00:00:00', 0),
(56, 1, '449', '2013-08-19', '1 x iPhone 5 16GB white', 1, 43750.00, '0000-00-00 00:00:00', 0),
(57, 1, '476', '2013-08-23', '1 x iPhone 4 8GB White', 1, 25481.00, '0000-00-00 00:00:00', 0),
(58, 1, '503', '2013-08-31', '2 x iPhone 4 8GB White', 2, 50962.00, '0000-00-00 00:00:00', 0),
(59, 1, '507', '2013-08-31', '1 x iPhone 5 16GB White', 1, 43750.00, '0000-00-00 00:00:00', 0),
(60, 1, '508', '2013-08-31', '1 x iPad 4 16GB WiFi White', 1, 30305.00, '0000-00-00 00:00:00', 0),
(61, 1, '523', '2013-08-31', '1 x iPhone 4 8GB Black', 1, 25481.00, '0000-00-00 00:00:00', 0),
(62, 1, '530', '2013-09-05', '1 x iPhone 5 16GB White', 1, 43750.00, '0000-00-00 00:00:00', 0),
(63, 1, '587', '2013-09-17', '1 x iPad 4 WiFi + Cellular 32GB Black', 1, 43605.01, '0000-00-00 00:00:00', 0),
(64, 1, '620', '2013-09-25', '5 x Lightning Cable', 5, 6404.97, '0000-00-00 00:00:00', 0),
(65, 1, '664', '2013-10-16', '1 x Apple Protection Plan', 1, 3514.00, '0000-00-00 00:00:00', 0),
(66, 1, '687', '2013-10-26', '7 x Lightning Cable', 7, 8966.96, '0000-00-00 00:00:00', 0),
(67, 1, '708', '2013-11-02', '2 x iPhone 5C 16GB Blue\n2 x iPhone 5C 16GB White\n2 x iPhone 5S 32GB Space Gray', 6, 281344.00, '0000-00-00 00:00:00', 0),
(68, 1, '760', '2013-11-02', '2 x Apple Protection Plan', 2, 7028.00, '0000-00-00 00:00:00', 0),
(69, 1, '788', '2013-11-18', '1 x iPhone 5S 16GB Space Gray\n1 x iPhone 5S 16GB Silver', 2, 102884.00, '0000-00-00 00:00:00', 0),
(70, 1, '799', '2013-11-19', '3 x Apple Protection Plan', 3, 10542.00, '0000-00-00 00:00:00', 0),
(71, 1, '828', '2013-11-23', '1 x iPhone 5S 16GB Gold', 1, 51442.00, '0000-00-00 00:00:00', 0),
(72, 1, '849', '2013-11-23', '3 x iPhone 5S Case', 3, 8421.01, '0000-00-00 00:00:00', 0),
(73, 1, '871', '2013-11-29', '2 x EarPods\n4 x iPhone 5C Case', 6, 12108.00, '0000-00-00 00:00:00', 0),
(74, 1, '873', '2013-11-30', '3 x iPad 4 WiFi + Cell 16GB White\n3 x iPad 4 WiFi 16GB Black', 6, 207114.00, '0000-00-00 00:00:00', 0),
(75, 1, '882', '2013-11-30', '1 x iPhone 5S 16GB Gold', 1, 51442.00, '0000-00-00 00:00:00', 0),
(76, 1, '891', '2013-12-03', '1 X iPhone 4S 8GB White', 1, 30288.00, '0000-00-00 00:00:00', 0),
(77, 1, '902', '2013-12-05', '1 x iPhone 5S 16GB Gold', 1, 51442.00, '0000-00-00 00:00:00', 0),
(78, 1, '938', '2013-12-09', '3 x iPhone 5S 16GB Gold', 3, 154326.00, '0000-00-00 00:00:00', 0),
(79, 1, '1103', '2013-12-26', '2 x iPhone 5S 16GB Gold', 2, 102884.00, '0000-00-00 00:00:00', 0),
(80, 1, '1178', '2014-01-22', '1 x iPhone 5S 16GB Silver\n2 x iPhone 5S 16GB Space Gray', 3, 154326.00, '0000-00-00 00:00:00', 0),
(81, 1, '1198', '2014-01-23', '1 x iPhone 4S 8GB White\n2 x iPhone 4S 8GB Black\n1 x iPhone 5S 16GB Gold', 4, 125767.99, '0000-00-00 00:00:00', 0),
(82, 1, '1210', '2014-01-25', '1 x iPhone 4S 8GB White\n1 x iPhone 4S 8GB Black\n4 x iPhone 5S 16GB Gold', 6, 266344.00, '0000-00-00 00:00:00', 0),
(83, 1, '1233', '2014-01-28', '6 x iPhone 4 8GB White\n4 x iPhone 4S 8GB White\n2 x iPhone 4S 8GB Black', 12, 313842.00, '0000-00-00 00:00:00', 0),
(84, 1, '1254', '2014-02-01', '5 x iPhone 4 8GB Black\n7 x iPhone 4 8GB White', 12, 264228.00, '0000-00-00 00:00:00', 0),
(85, 1, '1264', '2014-02-01', '4 x USB Power Adapter', 4, 5124.00, '0000-00-00 00:00:00', 0),
(86, 1, '1274', '2014-02-03', '10 x Lightning Cables', 10, 13160.05, '0000-00-00 00:00:00', 0),
(87, 1, '1318', '2014-02-10', '2 x iPhone 5S 16GB Silver', 2, 102884.00, '0000-00-00 00:00:00', 0),
(88, 1, '1331', '2014-02-14', '1 x iPhone 5S 16GB Silver', 1, 51442.00, '0000-00-00 00:00:00', 0),
(89, 1, '1342', '2014-02-15', '1 x iPhone 5C 16GB Pink', 1, 40288.00, '0000-00-00 00:00:00', 0),
(90, 1, '1353', '2014-02-15', '2 x iPhone 5S 16GB Gold\n2 x iPhone 5S 16GB Silver\n2 x iPhone 5S 16GB Space Gray', 6, 308652.00, '0000-00-00 00:00:00', 0),
(91, 1, '1360', '2014-02-15', '5 x USB Power Adapter', 5, 6404.97, '0000-00-00 00:00:00', 0),
(92, 1, '1367', '2014-02-19', '2 x Apple Protection Plan', 2, 7028.00, '0000-00-00 00:00:00', 0),
(93, 1, '1369', '2014-02-19', '1 x iPad Air 16GB WiFi + Cell Silver\n1 x iPad Mini 16GB WiFi Silver\n1 x iPad Mini 16GB WiFi + Cell Silver', 3, 93943.00, '0000-00-00 00:00:00', 0),
(94, 1, '1386', '2014-02-22', '2 x iPhone 5S 16GB Gold\n2 x iPhone 5S 16GB Silver', 4, 205768.00, '0000-00-00 00:00:00', 0),
(95, 1, '1395', '2014-02-26', '8 x iPhone 5S 16GB Gold', 8, 411536.00, '0000-00-00 00:00:00', 0),
(96, 1, '1403', '2014-02-26', '1 x iPhone 5S Case Black', 1, 5614.00, '0000-00-00 00:00:00', 0),
(97, 1, '1408', '2014-02-26', '1 x iPhone 5C 16GB White\n2 x iPhone 4S 8GB Black\n1 x iPhone 4S 8GB White\n1 x iPhone 5S 16GB Gold', 5, 182594.00, '0000-00-00 00:00:00', 0),
(98, 1, '1410', '2014-03-01', '1 x iPhone 5S 16GB Silver Demo', 1, 34930.00, '0000-00-00 00:00:00', 0),
(99, 1, '1414', '2014-03-01', '1 x iPad Mini 16GB WiFi Space Gray', 1, 42116.00, '0000-00-00 00:00:00', 0),
(100, 1, '1425', '2014-03-03', '1 x iPad 4 16GB WiFi + Cell Black', 1, 38365.00, '0000-00-00 00:00:00', 0),
(101, 1, '1426', '2014-03-03', '1 x iPad Mini RD 16GB WiFi + Cell Silver', 1, 36442.00, '0000-00-00 00:00:00', 0),
(102, 1, '1438', '2014-03-03', '2 x iPhone 5S 16GB Space Gray', 2, 102884.00, '0000-00-00 00:00:00', 0),
(103, 1, '1439', '2014-03-03', '1 x iPad Mini 16GB WiFi + Cell Silver', 1, 29712.00, '0000-00-00 00:00:00', 0),
(104, 1, '1440', '2014-03-03', '7 x Lightning Cable', 7, 9212.00, '0000-00-00 00:00:00', 0),
(105, 1, '1444', '2014-03-03', '1 x iPhone 5C 16GB Yellow', 1, 40288.00, '0000-00-00 00:00:00', 0),
(106, 1, '1445', '2014-03-03', '1 x iPod Shuffle 2GB Pink\n1 x iPod Shuffle 2GB Silver', 2, 6852.00, '0000-00-00 00:00:00', 0),
(107, 1, '1447', '2014-03-03', '2 x iPhone 5S 16GB Gold', 2, 102884.00, '0000-00-00 00:00:00', 0),
(108, 1, '1461', '2014-03-03', '10 x Apple Protection Plan', 10, 35140.00, '0000-00-00 00:00:00', 0),
(109, 1, '1471', '2014-03-03', '1 x iPhone 5S 64GB Silver', 1, 68750.00, '0000-00-00 00:00:00', 0),
(110, 1, '1477', '2014-03-13', '1 x iPad Air 16GB WiFi + Cell Silver', 1, 43173.00, '0000-00-00 00:00:00', 0),
(111, 1, '1478', '2014-03-13', '1 x iPod Shuffle 2GB Space Gray\n1 x iPod Shuffle 2GB Green\n1 x iPod Shuffle 2GB Yellow', 3, 10278.00, '0000-00-00 00:00:00', 0),
(112, 1, '1494', '2014-03-13', '20 x Lightning Cable\n1 x 5C Dock\n1 x 5S Dock\n3 x 5S Case', 25, 30356.09, '0000-00-00 00:00:00', 0),
(113, 1, '1496', '2014-03-13', '1 x iPad Mini 16GB WiFi + Cell Silver', 1, 29712.10, '0000-00-00 00:00:00', 0),
(114, 1, '1508', '2014-03-20', '1 x iPad Air 16GB WiFi Silver', 1, 34519.24, '0000-00-00 00:00:00', 0),
(115, 1, '1511', '2014-03-20', '5 x USB Power Adapter\n1 x 30 Pin Adapter', 6, 8237.97, '0000-00-00 00:00:00', 0),
(116, 1, '1527', '2014-03-26', '2 x iPad Mini 16GB WiFi Silver', 2, 42115.99, '0000-00-00 00:00:00', 0),
(117, 1, '1533', '2014-03-28', '2 x iPhone 5S 16GB Space Gray\n1 x iPhone 4S 8GB White', 3, 133172.00, '0000-00-00 00:00:00', 0),
(118, 1, '1534', '2014-03-28', '2 x Apple Protection Plan', 2, 7028.00, '0000-00-00 00:00:00', 0),
(120, 1, '891', '2013-12-03', '1 X iPhone 4S 8GB White', 1, 30288.00, '0000-00-00 00:00:00', 0);

-- --------------------------------------------------------

--
-- Table structure for table `distributors`
--

CREATE TABLE IF NOT EXISTS `distributors` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  `contactperson` varchar(64) NOT NULL,
  `address` text NOT NULL,
  `mobile` varchar(12) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `email` varchar(64) NOT NULL,
  `tin` varchar(32) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `distributors`
--

INSERT INTO `distributors` (`id`, `name`, `contactperson`, `address`, `mobile`, `phone`, `email`, `tin`) VALUES
(1, 'Vision Telecommunications Pvt. Ltd.', 'Manmohan Swaraj', 'Vision Telecommunication India Pvt Ltd-Punjab\r\nOpp. Mayur Hotel, Behind Indian Overseas Bank, Zirakpur\r\nPunjab', '8591239007', '9988888950', 'manmohan@ksons.co.in', '03062151092'),
(2, 'BAMA Infotech', 'Gurdeep Singh', '14-D, Kitchlu Nagar, Opp. Lions Club, Ludhiana - 141 001, Punjab, India.', '8146321400', '01615031333', 'info@bamainfotech.com', '03051110336'),
(3, 'Dummy Distributor', 'BKM', 'Some place nice', '9', '12345677', '22bankim@gmail.com', '1');

-- --------------------------------------------------------

--
-- Table structure for table `problemsreportedtypes`
--

CREATE TABLE IF NOT EXISTS `problemsreportedtypes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(64) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `type` (`type`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `problemsreportedtypes`
--

INSERT INTO `problemsreportedtypes` (`id`, `type`) VALUES
(2, 'Dock Related'),
(1, 'Earpiece Related');

-- --------------------------------------------------------

--
-- Table structure for table `productaccessories`
--

CREATE TABLE IF NOT EXISTS `productaccessories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(64) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `type` (`type`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `productaccessories`
--

INSERT INTO `productaccessories` (`id`, `type`) VALUES
(2, 'Earphones'),
(1, 'Power Adapter');

-- --------------------------------------------------------

--
-- Table structure for table `productconditiontypes`
--

CREATE TABLE IF NOT EXISTS `productconditiontypes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(64) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `type` (`type`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `productconditiontypes`
--

INSERT INTO `productconditiontypes` (`id`, `type`) VALUES
(2, 'Minor Dents & Scratches'),
(1, 'Minor Scuffs & Scratches');

-- --------------------------------------------------------

--
-- Table structure for table `productparts`
--

CREATE TABLE IF NOT EXISTS `productparts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `parts` varchar(64) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `diagnosis` (`parts`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

--
-- Dumping data for table `productparts`
--

INSERT INTO `productparts` (`id`, `parts`) VALUES
(11, 'Bluetooth'),
(7, 'Digitiser/Display'),
(2, 'Earphone Jack'),
(9, 'Front Cam'),
(6, 'Home Button/Fingerprint Sensor'),
(5, 'Microphone'),
(8, 'Proximity Sensor'),
(10, 'Rear Camera'),
(1, 'Sleep/Wake Button Flex'),
(4, 'Speaker'),
(3, 'USB/Dock'),
(12, 'WiFi');

-- --------------------------------------------------------

--
-- Table structure for table `repairjobs`
--

CREATE TABLE IF NOT EXISTS `repairjobs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `inwarddate` datetime NOT NULL,
  `dateofdeposit` datetime NOT NULL,
  `dateofreturn` datetime NOT NULL,
  `outwarddate` datetime NOT NULL,
  `productmodelid` int(10) unsigned NOT NULL,
  `productserialnumber` varchar(128) NOT NULL,
  `dateofpurchase` date NOT NULL,
  `productconditionid` int(10) unsigned NOT NULL,
  `name` varchar(64) NOT NULL,
  `address` varchar(255) NOT NULL,
  `mobileno` varchar(16) NOT NULL,
  `email` varchar(128) NOT NULL,
  `modified` datetime NOT NULL,
  `modifiedby` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `inwarddate` (`inwarddate`),
  KEY `productmodelid` (`productmodelid`),
  KEY `mobileno` (`mobileno`),
  KEY `productconditionid` (`productconditionid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `repairjobs`
--

INSERT INTO `repairjobs` (`id`, `inwarddate`, `dateofdeposit`, `dateofreturn`, `outwarddate`, `productmodelid`, `productserialnumber`, `dateofpurchase`, `productconditionid`, `name`, `address`, `mobileno`, `email`, `modified`, `modifiedby`) VALUES
(1, '2014-10-26 18:29:43', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 2, '111231333313', '2014-10-26', 2, 'Bankim Bhagat', 'Prem Nagar', '', '22bankim@gmail.com', '2014-10-26 18:30:24', 0),
(2, '2014-10-27 01:37:28', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 2, '11123133331311ssZ', '2014-10-27', 2, 'Bankim Bhagat', 'skds kdd', '99848848488', '22bankim@gmail.com', '2014-10-27 01:37:54', 0),
(3, '2014-10-27 03:18:11', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 2, '11123133331311ssZ', '2014-10-27', 1, 'Bankim Bhagat', 'dlslsd', '999899888', '22bankim@gmail.com', '2014-10-27 03:19:28', 1);

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE IF NOT EXISTS `roles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role` varchar(255) NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `admin` tinyint(1) NOT NULL DEFAULT '0',
  `viewallactionlog` tinyint(1) NOT NULL DEFAULT '0',
  `createusers` tinyint(1) NOT NULL DEFAULT '0',
  `changeownpassword` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `role` (`role`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `role`, `enabled`, `admin`, `viewallactionlog`, `createusers`, `changeownpassword`) VALUES
(1, 'Administrator', 1, 1, 1, 1, 1),
(2, 'View Reports', 1, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `salesinvoice`
--

CREATE TABLE IF NOT EXISTS `salesinvoice` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `invoicedate` date NOT NULL,
  `customername` varchar(64) NOT NULL,
  `customermobile` varchar(12) NOT NULL,
  `address` text NOT NULL,
  `email` varchar(64) NOT NULL,
  `comment` text NOT NULL,
  `modfied` datetime NOT NULL,
  `modifiedby` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `modifiedby` (`modifiedby`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `salesinvoiceitems`
--

CREATE TABLE IF NOT EXISTS `salesinvoiceitems` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `salesinvoiceid` int(10) unsigned NOT NULL,
  `stockitemid` int(10) unsigned NOT NULL,
  `discount` decimal(12,2) NOT NULL,
  `rp` decimal(12,2) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `salesinvoiceid` (`salesinvoiceid`,`stockitemid`),
  KEY `stockitemid` (`stockitemid`),
  KEY `salesinvoiceid_2` (`salesinvoiceid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `stockitems`
--

CREATE TABLE IF NOT EXISTS `stockitems` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `stockitemtypeid` int(10) unsigned NOT NULL,
  `distributorinvoiceid` int(10) unsigned NOT NULL,
  `sku` varchar(64) NOT NULL,
  `barcode` varchar(256) NOT NULL,
  `itemname` varchar(64) NOT NULL,
  `bp` decimal(12,2) NOT NULL COMMENT 'Base price without tax',
  `taxrateid` int(3) unsigned NOT NULL,
  `description` text NOT NULL,
  `mrp` decimal(12,2) NOT NULL,
  `quantity` int(11) NOT NULL DEFAULT '1' COMMENT 'Quantity of Similar Items in Stock',
  `salesinvoiceid` int(10) unsigned NOT NULL,
  `modified` datetime NOT NULL,
  `modifiedby` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `stockitemtypeid` (`stockitemtypeid`),
  KEY `distributorinvoiceid` (`distributorinvoiceid`),
  KEY `salesinvoiceid` (`salesinvoiceid`),
  KEY `modifiedby` (`modifiedby`),
  KEY `barcode` (`barcode`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `stockitems`
--

INSERT INTO `stockitems` (`id`, `stockitemtypeid`, `distributorinvoiceid`, `sku`, `barcode`, `itemname`, `bp`, `taxrateid`, `description`, `mrp`, `quantity`, `salesinvoiceid`, `modified`, `modifiedby`) VALUES
(2, 3, 2, '112333444', '112112334', 'HTC One X', 10000.00, 1, '', 20000.00, 10, 0, '2014-02-05 02:32:04', 0),
(3, 2, 2, '3222344', '112112334111', 'iPhone 5S', 30000.00, 1, '', 60000.00, 5, 0, '2014-02-05 02:33:51', 0),
(4, 2, 2, 'MG782HN/A', 'thisisthat', 'iPhone 5S 16GB Gold', 47500.00, 1, '', 53500.00, 1, 0, '2015-04-19 18:20:37', 0),
(5, 2, 5, '', '', 'iPhone 5S 16GB Gold', 47043.43, 2, '', 53500.00, 1, 0, '2015-05-02 02:17:59', 0),
(6, 2, 4, 'MF266HN/A', '', 'iPhone 4S 8GB White', 27698.22, 2, '', 31500.00, 1, 0, '2015-05-02 02:29:52', 0),
(7, 2, 4, 'MF266HN/A', '', 'iPhone 4S 8GB White', 27698.22, 2, '', 31500.00, 1, 0, '2015-05-02 02:29:52', 0);

-- --------------------------------------------------------

--
-- Table structure for table `stockitemtypes`
--

CREATE TABLE IF NOT EXISTS `stockitemtypes` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `parentcategoryid` int(11) unsigned NOT NULL,
  `type` varchar(32) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `type` (`type`),
  KEY `parentcategoryid` (`parentcategoryid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=48 ;

--
-- Dumping data for table `stockitemtypes`
--

INSERT INTO `stockitemtypes` (`id`, `parentcategoryid`, `type`) VALUES
(1, 0, 'iPhone'),
(2, 1, '4 8GB Black'),
(3, 1, '4 8GB White'),
(4, 1, '4 16GB Black'),
(5, 1, '4 16GB White'),
(6, 1, ' 4S 8GB Black'),
(7, 1, '4S 8GB White'),
(8, 1, '5 16GB Slate Gray'),
(9, 1, '5 16GB Silver'),
(10, 1, '5 32GB Slate Gray'),
(11, 1, '5 32GB Silver'),
(12, 1, '5S 16GB Gold'),
(13, 1, '5S 16GB Space Gray'),
(14, 1, '5S 16GB Silver'),
(15, 1, '5S 32GB Gold'),
(16, 1, '5S 32GB Space Gray'),
(17, 1, '5S 32GB Silver'),
(18, 1, '5S 64GB Gold'),
(19, 1, '5S 64GB Space Gray'),
(20, 1, '5S 64GB Silver'),
(21, 1, '6 16GB Gold'),
(22, 1, '6 16GB Space Gray'),
(23, 1, '6 16GB Silver'),
(24, 1, '6 64GB Gold'),
(25, 1, '6 64GB Space Gray'),
(26, 1, '6 64GB Silver'),
(27, 1, '6 128GB Gold'),
(28, 1, '6 128GB Space Gray'),
(29, 1, '6 128GB Silver'),
(30, 1, '6 Plus 16GB Gold'),
(31, 1, '6 Plus 16GB Space Gray'),
(32, 1, '6 Plus 16GB Silver'),
(33, 1, '6 Plus 64GB Gold'),
(34, 1, '6 Plus 64GB Space Gray'),
(35, 1, '6 Plus 64GB Silver'),
(36, 1, '6 Plus 128GB Gold'),
(37, 1, '6 Plus 128GB Space Gray'),
(38, 1, '6 Plus 128GB Silver'),
(39, 0, 'iPad'),
(40, 39, 'Mini 16GB WiFi Gray'),
(41, 39, 'Mini 16GB WiFi Silver'),
(42, 39, 'Mini 16GB WiFi + Cell Gray'),
(43, 39, 'Mini 16GB WiFi + Cell Silver'),
(44, 39, 'Mini 32GB WiFi Gray'),
(45, 39, 'Mini 32GB WiFi Silver'),
(46, 39, 'Mini 32GB WiFi + Cell Gray'),
(47, 39, 'Mini 32GB WiFi + Cell Silver');

-- --------------------------------------------------------

--
-- Table structure for table `taxrates`
--

CREATE TABLE IF NOT EXISTS `taxrates` (
  `id` int(3) unsigned NOT NULL AUTO_INCREMENT,
  `description` varchar(64) NOT NULL,
  `taxrate` decimal(4,2) NOT NULL,
  `validfrom` date NOT NULL COMMENT 'Date rate applicable',
  `validto` date NOT NULL COMMENT 'Date rate applicable upto',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COMMENT='Tax rates applicable' AUTO_INCREMENT=4 ;

--
-- Dumping data for table `taxrates`
--

INSERT INTO `taxrates` (`id`, `description`, `taxrate`, `validfrom`, `validto`) VALUES
(1, '13% - Accessory and iPod', 14.30, '2013-04-01', '2016-03-31'),
(2, '8.5% - Phones', 9.35, '2013-04-01', '2016-03-31'),
(3, '5.5% - IT Products', 6.05, '2015-04-01', '2016-03-31');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `lastlogin` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `local` varchar(10) NOT NULL DEFAULT 'en',
  `role` tinyint(1) NOT NULL DEFAULT '0',
  `mod_datetime` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `lastlogin`, `enabled`, `local`, `role`, `mod_datetime`) VALUES
(1, 'admin', '21232f297a57a5a743894a0e4a801fc3', '2015-05-08 01:10:56', 1, 'en', 1, '2009-04-20 14:08:40');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `salesinvoiceitems`
--
ALTER TABLE `salesinvoiceitems`
  ADD CONSTRAINT `salesinvoiceitems_ibfk_1` FOREIGN KEY (`salesinvoiceid`) REFERENCES `salesinvoice` (`id`),
  ADD CONSTRAINT `salesinvoiceitems_ibfk_2` FOREIGN KEY (`stockitemid`) REFERENCES `stockitems` (`id`);

--
-- Constraints for table `stockitems`
--
ALTER TABLE `stockitems`
  ADD CONSTRAINT `stockitems_ibfk_1` FOREIGN KEY (`stockitemtypeid`) REFERENCES `stockitemtypes` (`id`),
  ADD CONSTRAINT `stockitems_ibfk_2` FOREIGN KEY (`distributorinvoiceid`) REFERENCES `distributorinvoices` (`id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
